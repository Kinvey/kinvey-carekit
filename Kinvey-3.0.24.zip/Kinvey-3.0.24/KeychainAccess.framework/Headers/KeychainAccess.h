//
//  KeychainAccess.h
//  KeychainAccess
//
//  Created by kishikawa katsumi on 2014/12/24.
//  Copyright (c) 2014 kishikawa katsumi. All rights reserved.
//

#import <Foundation/Foundation.h>

FOUNDATION_EXPORT double KeychainAccessVersionNumber;
FOUNDATION_EXPORT const unsigned char KeychainAccessVersionString[];
