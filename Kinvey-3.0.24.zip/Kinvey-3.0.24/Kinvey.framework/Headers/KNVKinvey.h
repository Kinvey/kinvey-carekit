//
//  KNVKinvey.h
//  Kinvey
//
//  Created by Victor Barros on 2016-03-04.
//  Copyright © 2016 Kinvey. All rights reserved.
//

#import <Foundation/Foundation.h>

extern NSString* const KNVPersistableIdKey;
extern NSString* const KNVPersistableAclKey;
extern NSString* const KNVPersistableMetadataKey;
